import sqlite3pkg from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const sqlite3 = sqlite3pkg.verbose();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dbPath = join(__dirname, '../data/players.db');

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Database connection error:', err);
        process.exit(1);
    }
    console.log('Connected to database:', dbPath);
    
    // 清空玩家表
    db.run('DELETE FROM players', (err) => {
        if (err) {
            console.error('Error cleaning database:', err);
            process.exit(1);
        }
        console.log('Successfully cleaned players table');
        db.close(() => {
            console.log('Database connection closed');
            process.exit(0);
        });
    });
});
